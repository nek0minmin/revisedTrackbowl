
import static javax.swing.SwingConstants.CENTER;
import static javax.swing.SwingConstants.LEFT;

import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;
import net.proteanit.sql.DbUtils;
import java.awt.HeadlessException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author User
 */
public final class Display extends javax.swing.JFrame {

    private final DefaultTableModel model;
    private final TableRowSorter<DefaultTableModel> sorter;
    static String accType;
    static String userLabel;
    static String staffid;
    static String dateToday;
    static String passId = staffid;
    static String staffName;

    public Display(String accType, String userLabel, String staffid) {
        this.staffid = staffid;
        this.accType = accType;
        this.userLabel = userLabel;
        initComponents();
        customizeTable();
        inventoryTable.setModel(tableModel);
        showTable();
        showCurrentDate();
        setCustomRenderer();
        fetchData();

        model = (DefaultTableModel) inventoryTable.getModel();
        sorter = new TableRowSorter<>(model);
        inventoryTable.setRowSorter(sorter);
        TableColumnModel columnModel = inventoryTable.getColumnModel();

        staffWelcome.setVisible(false);
        for (int i = 0; i < columnModel.getColumnCount(); i++) {
            TableColumn column = columnModel.getColumn(i);
            column.setResizable(false);
        }

        System.out.println("Logged in: " + accType + "\n" + staffid);
        if (accType.equals("Staff")) {
            back.setVisible(false);
            staffWelcome.setText("Active Staff:  " + staffid);
            active.setText("Active user: " + staffName + " - " + staffid);

        } else if (accType.equals("Admin")) {
            logOut.setVisible(false);
            viewAccount.setVisible(false);
            label.setVisible(false);
            staffWelcome.setText("Active Staff: Admin");
            active.setText("Active user: " + "Admin");
        }

    }

    Connection con = null; //connects java n db
    PreparedStatement pst = null; //accesses data
    ResultSet rs = null; //

    void customizeTable() {
        inventoryTable.setDefaultEditor(Object.class, null);

        inventoryTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                int stocksLeftColumnIndex = 4;
                int expDateColumnIndex = 5;

                if (row >= 0) {
                    try {
                        int stocksLeft = Integer.parseInt(table.getValueAt(row, stocksLeftColumnIndex).toString());
                        String expDateString = table.getValueAt(row, expDateColumnIndex).toString();
                        LocalDate currentDate = LocalDate.now();
                        LocalDate expDate = LocalDate.parse(expDateString, dateFormatter);

                        if (stocksLeft < 5 || expDate.isBefore(currentDate) || expDate.isEqual(currentDate)) {
                            c.setBackground(Color.RED);
                        } else {
                            c.setBackground(table.getBackground());
                        }
                    } catch (NumberFormatException | NullPointerException | java.time.format.DateTimeParseException e) {
                        c.setBackground(table.getBackground());
                    }
                } else {
                    c.setBackground(table.getBackground());
                }

                if (isSelected) {
                    c.setBackground(inventoryTable.getSelectionBackground());
                    c.setForeground(inventoryTable.getSelectionForeground());
                } else {
                    c.setForeground(table.getForeground());
                }

                return c;
            }
        });
    }

    public void fetchData() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/trackbowl", "root", ""); // Update with your DB credentials
            String query = "SELECT * FROM `staff_accounts` WHERE `id` = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, staffid);
            rs = pst.executeQuery();

            if (rs.next()) {
                staffName = rs.getString("Name");

            }

        } catch (java.sql.SQLException ex) {
            Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (java.sql.SQLException ex) {
                Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void setCustomRenderer() {
        CustomTableCellRenderer renderer = new CustomTableCellRenderer();
        // Assuming your image column index is 1, adjust this based on your table model
        inventoryTable.getColumnModel().getColumn(1).setCellRenderer(renderer);
    }

    public void showTable() {

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/trackbowl", "root", "");
            String sql = "SELECT * FROM inventory_items";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();

            // Convert ResultSet to DefaultTableModel using DbUtils
            DefaultTableModel model = (DefaultTableModel) DbUtils.resultSetToTableModel(rs);

            // Assuming 'Item Image' is the column index where images are stored
            int imageColumnIndex = 1; // Adjust based on your table structure

            // Replace byte[] with ImageIcon in the model for image column
            for (int row = 0; row < model.getRowCount(); row++) {
                byte[] imageData = (byte[]) model.getValueAt(row, imageColumnIndex);
                if (imageData != null) {
                    ImageIcon imageIcon = new ImageIcon(imageData);
                    model.setValueAt(imageIcon, row, imageColumnIndex);
                }
            }

            // Set the model to the table
            inventoryTable.setModel(model);

            // Apply custom renderer to all columns
            CustomTableCellRenderer renderer = new CustomTableCellRenderer();
            for (int i = 0; i < inventoryTable.getColumnCount(); i++) {
                inventoryTable.getColumnModel().getColumn(i).setCellRenderer(renderer);
            }

            // Set column width for the image column (if needed)
            int ICON_WIDTH = 100; // Assuming width of 100 pixels for the image
            inventoryTable.getColumnModel().getColumn(imageColumnIndex).setPreferredWidth(ICON_WIDTH);

            // Set row height after setting model
            int ICON_HEIGHT = 100; // Assuming height of 100 pixels for the image
            inventoryTable.setRowHeight(ICON_HEIGHT + 10); // Adjust row height based on icon size

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        active = new javax.swing.JLabel();
        staffId = new javax.swing.JLabel();
        staffWelcome = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        inventoryTable = new javax.swing.JTable();
        buyItem = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        searchBar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        logOut = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        currentDateField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        itemsSoldToday1 = new javax.swing.JButton();
        back = new javax.swing.JLabel();
        label = new javax.swing.JLabel();
        viewAccount = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TrackBowl Sell Items");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setPreferredSize(new java.awt.Dimension(520, 560));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        active.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        active.setText("jLabel6");
        jPanel5.add(active, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 260, 30));
        jPanel5.add(staffId, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 60, 20));

        staffWelcome.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        jPanel5.add(staffWelcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 220, 20));

        jPanel2.setBackground(new java.awt.Color(204, 0, 0));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        inventoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Code", "Item Image", "Item Name", "Item Price (₱)", "Stocks Left", "Exp Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        inventoryTable.setSelectionBackground(new java.awt.Color(153, 0, 0));
        inventoryTable.setSelectionForeground(new java.awt.Color(102, 0, 0));
        inventoryTable.getTableHeader().setReorderingAllowed(false);
        inventoryTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inventoryTableMouseClicked(evt);
            }
        });
        inventoryTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                inventoryTableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(inventoryTable);
        if (inventoryTable.getColumnModel().getColumnCount() > 0) {
            inventoryTable.getColumnModel().getColumn(0).setResizable(false);
            inventoryTable.getColumnModel().getColumn(1).setResizable(false);
            inventoryTable.getColumnModel().getColumn(2).setResizable(false);
            inventoryTable.getColumnModel().getColumn(3).setResizable(false);
            inventoryTable.getColumnModel().getColumn(4).setResizable(false);
            inventoryTable.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 618, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel5.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 630, 390));

        buyItem.setBackground(new java.awt.Color(204, 0, 0));
        buyItem.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        buyItem.setForeground(new java.awt.Color(255, 255, 255));
        buyItem.setText("Sell Item");
        buyItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buyItemActionPerformed(evt);
            }
        });
        jPanel5.add(buyItem, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 490, 155, 40));

        jPanel4.setBackground(new java.awt.Color(204, 0, 0));

        jLabel4.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Search Item Name: ");

        searchBar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                searchBarMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                searchBarMouseReleased(evt);
            }
        });
        searchBar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBarActionPerformed(evt);
            }
        });
        searchBar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchBarKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchBar, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(searchBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );

        jPanel5.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 20, 290, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trackbowlPics/tabsBG.png"))); // NOI18N
        jPanel5.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 540));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 700, 540));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logOut.setBackground(new java.awt.Color(255, 153, 51));
        logOut.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        logOut.setForeground(new java.awt.Color(255, 255, 255));
        logOut.setText("LOG-OUT");
        logOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logOutActionPerformed(evt);
            }
        });
        jPanel6.add(logOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 480, 150, 30));

        jLabel2.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jLabel2.setText(" SELL ITEMS ");
        jPanel6.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 140, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trackbowlPics/logo1 (1).png"))); // NOI18N
        jPanel6.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        jPanel7.setBackground(new java.awt.Color(204, 0, 0));

        currentDateField.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentDateField, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentDateField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 150, -1));

        jLabel5.setBackground(new java.awt.Color(204, 0, 0));
        jLabel5.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 0));
        jLabel5.setText("Today's Date:");
        jPanel6.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 150, 20));

        itemsSoldToday1.setBackground(new java.awt.Color(204, 0, 0));
        itemsSoldToday1.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        itemsSoldToday1.setForeground(new java.awt.Color(255, 255, 255));
        itemsSoldToday1.setText("SOLD ITEMS");
        itemsSoldToday1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemsSoldToday1ActionPerformed(evt);
            }
        });
        jPanel6.add(itemsSoldToday1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 150, 40));

        back.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        back.setForeground(new java.awt.Color(153, 0, 0));
        back.setText("<<Back");
        back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backMouseClicked(evt);
            }
        });
        jPanel6.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, 80, -1));

        label.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        label.setText("View your account information");
        jPanel6.add(label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 180, 20));

        viewAccount.setBackground(new java.awt.Color(204, 0, 0));
        viewAccount.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        viewAccount.setForeground(new java.awt.Color(255, 255, 255));
        viewAccount.setText("ACCOUNT INFO");
        viewAccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewAccountActionPerformed(evt);
            }
        });
        jPanel6.add(viewAccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 150, 40));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel7.setText("View all items sold today");
        jPanel6.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 170, 20));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 170, 540));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 906, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 564, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public void showCurrentDate() {
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Manila"));

        // Get the current date and format it
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String currentDate = dateFormat.format(new Date());

        // Set the current date as the text of the JTextField
        currentDateField.setText(currentDate);
        currentDateField.setEditable(false);
        dateToday = currentDate;
    }

    private void logOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logOutActionPerformed
        // TODO add your handling code here:

        int reply = JOptionPane.showConfirmDialog(this, "Log-out of this account? ", "Log-out of Account", JOptionPane.YES_NO_OPTION);

        if (reply == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Logging out of account...", "Logging-out of Account", JOptionPane.INFORMATION_MESSAGE);

            dispose();
            FinalLoginPage login = new FinalLoginPage();
            login.show();

        } else {

        }

    }//GEN-LAST:event_logOutActionPerformed


    private void buyItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buyItemActionPerformed
        int selectedRow = inventoryTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a row of item to sell", "No Item Selected", JOptionPane.ERROR_MESSAGE);
    } else {
        // Check if expiration date is before or equal to current date
        String expDateString = inventoryTable.getValueAt(selectedRow, 5).toString();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate expDate = LocalDate.parse(expDateString, formatter);
        LocalDate currentDate = LocalDate.now();

        if (expDate.isBefore(currentDate) || expDate.isEqual(currentDate)) {
            JOptionPane.showMessageDialog(this, "You can't sell an expired item", "Expired Item", JOptionPane.ERROR_MESSAGE);
        } else {
            String input = JOptionPane.showInputDialog(this, "Enter amount of " + inventoryTable.getValueAt(selectedRow, 2) + " to sell: (e.g 4)", "Buy Quantity"
                    + "\nPrice: ₱" + inventoryTable.getValueAt(selectedRow, 3)
                    + "\nStocks Available: " + inventoryTable.getValueAt(selectedRow, 4), JOptionPane.QUESTION_MESSAGE);

            if (input == null || input.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Selling item cancelled", "Cancellation", JOptionPane.ERROR_MESSAGE);
            } else if (!input.matches("^[0-9]+$")) {
                JOptionPane.showMessageDialog(this, "Enter a valid quantity of item!\n(e.g 4)", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            } else {
                int buyQuantity = Integer.parseInt(input);
                String itemCode = inventoryTable.getValueAt(selectedRow, 0).toString();
                String itemName = inventoryTable.getValueAt(selectedRow, 2).toString();
                double sellingPrice = Double.parseDouble(inventoryTable.getValueAt(selectedRow, 3).toString());
                int currentStock = Integer.parseInt(inventoryTable.getValueAt(selectedRow, 4).toString());

                if (buyQuantity <= 0) {
                    JOptionPane.showMessageDialog(this, "Quantity must not be less than or equal to 0", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                } else if (buyQuantity > currentStock) {
                    JOptionPane.showMessageDialog(this, "Insufficient Stocks of " + inventoryTable.getValueAt(selectedRow, 2) + "!"
                            + "\nStocks Available: " + inventoryTable.getValueAt(selectedRow, 4), "Invalid Input", JOptionPane.ERROR_MESSAGE);
                } else {
                    double totalPrice = buyQuantity * sellingPrice;
                    int reply = JOptionPane.showConfirmDialog(this, "Sell " + buyQuantity + " pieces of " + itemName + "?"
                            + "\nTotal Price: ₱" + totalPrice, "Confirmation", JOptionPane.YES_NO_OPTION);

                    if (reply == JOptionPane.YES_OPTION) {
                        String[] options = {"Cash", "G-cash", "Cancel"};
                        int response = JOptionPane.showOptionDialog(
                                this, // parent component
                                "Select Mode of Payment", // message
                                "Payment Mode", // title
                                JOptionPane.DEFAULT_OPTION, // option type
                                JOptionPane.PLAIN_MESSAGE, // message type
                                null, // icon
                                options, // options
                                options[0] // initial value
                        );

                        String mop = "";
                        // Handle the response
                        switch (response) {
                            case 0:
                                System.out.println("Cash selected");
                                mop = "Cash";
                                break;
                            case 1:
                                System.out.println("Gcash selected");
                                mop = "G-cash";
                                break;
                            case 2:
                            case JOptionPane.CLOSED_OPTION:
                                System.out.println("Cancelled");
                                return; // Exit if cancelled
                            default:
                                break;
                        }

                        // Update current stock in the table
                        currentStock -= buyQuantity;
                        inventoryTable.setValueAt(currentStock, selectedRow, 4);

                        // Perform database operations
                        try {
                            addItemToSoldTable(itemCode, itemName, buyQuantity, totalPrice, mop, staffid, dateToday);
                            //allItemsSold(itemName, buyQuantity, totalPrice, mop, staffid, dateToday);
                            updateStock(itemCode, currentStock);

                            JOptionPane.showMessageDialog(this, "Purchase completed successfully!"
                                    + "\nItem Sold: " + itemName
                                    + "\nQuantity: " + buyQuantity
                                    + "\nTotal Price: ₱" + totalPrice
                                    + "\nStaff Responsible: " + staffid, "Selling Item Successful", JOptionPane.INFORMATION_MESSAGE);
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                            ex.printStackTrace();
                        }

                    } else {
                        JOptionPane.showMessageDialog(this, "Selling Item Cancelled", "Selling Cancellation", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        }
    }


    }//GEN-LAST:event_buyItemActionPerformed

    public String getId() {
        String id = staffid;
        return id;
    }

    void updateStock(String idString, int quantity) {
        int id = Integer.parseInt(idString);

        try {
            String sql = "UPDATE inventory_items SET `Stocks Left`=? WHERE id=?";
            con = DriverManager.getConnection("jdbc:mysql://localhost/trackbowl", "root", "");
            pst = con.prepareStatement(sql);
            pst.setInt(2, id);
            pst.setInt(1, quantity);
            pst.executeUpdate();

        } catch (SQLException | HeadlessException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

    }

    void addItemToSoldTable(String itemCode, String itemName, int buyQuantity, double totalPrice, String mop, String staffid, String date) {

        try {
            String sql = "INSERT INTO itemsoldtable"
                    + "(`item_code`,`item_name`, `quantity`, `total_price`, `Mode`, `staff_id`, `date sold`)"
                    + "VALUES (?,?,?,?,?,?,?)";

            con = DriverManager.getConnection("jdbc:mysql://localhost/trackbowl", "root", "");
            pst = con.prepareStatement(sql);
            pst.setString(1, itemCode);
            pst.setString(2, itemName);
            pst.setInt(3, buyQuantity);
            pst.setDouble(4, totalPrice);
            pst.setString(5, mop);
            pst.setString(6, staffid);
            pst.setString(7, date);
            pst.executeUpdate();

        } catch (HeadlessException | SQLException ex) {

            JOptionPane.showMessageDialog(null, ex);
        }
    }


    private void searchBarMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchBarMouseReleased

    }//GEN-LAST:event_searchBarMouseReleased

    private void searchBarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBarActionPerformed

    private void searchBarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchBarMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBarMousePressed

    private void inventoryTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inventoryTableKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_inventoryTableKeyReleased

    private void searchBarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchBarKeyReleased
        // TODO add your handling code here:
        String search = searchBar.getText().toLowerCase();
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + search, 2));
    }//GEN-LAST:event_searchBarKeyReleased

    private void itemsSoldToday1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemsSoldToday1ActionPerformed
        // TODO add your handling code here:
        dispose();
        ItemsSoldToday items = new ItemsSoldToday(accType, staffid);
        items.show();
    }//GEN-LAST:event_itemsSoldToday1ActionPerformed

    private void inventoryTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inventoryTableMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_inventoryTableMouseClicked

    private void backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backMouseClicked
        // TODO add your handling code here:
        dispose();
        DashBoard dash = new DashBoard("Admin");
        dash.show();
    }//GEN-LAST:event_backMouseClicked

    private void viewAccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewAccountActionPerformed
        // TODO add your handling code here:
        AccountInfo info = new AccountInfo(staffid);
        System.out.println(staffid);
        info.show();
        dispose();
    }//GEN-LAST:event_viewAccountActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Display.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Display.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Display.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Display.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Display(accType, userLabel, staffid).setVisible(true);
            }
        });
    }

    DefaultTableModel tableModel = new DefaultTableModel() {

        public boolean isCellEditable(int row, int column) {
            return false;
        }

    };

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel active;
    private javax.swing.JLabel back;
    private javax.swing.JButton buyItem;
    private javax.swing.JTextField currentDateField;
    private javax.swing.JTable inventoryTable;
    private javax.swing.JButton itemsSoldToday1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label;
    private javax.swing.JButton logOut;
    private javax.swing.JTextField searchBar;
    private javax.swing.JLabel staffId;
    private javax.swing.JLabel staffWelcome;
    private javax.swing.JButton viewAccount;
    // End of variables declaration//GEN-END:variables
}

class CustomTableCellRenderer extends DefaultTableCellRenderer {

    private static final int ICON_WIDTH = 100;
    private static final int ICON_HEIGHT = 100;

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        int imageColumnIndex = 1; // Adjust based on your table structure
        int stockColumnIndex = 4; // Column index for stock

        // Check if the current column is the image column and value is an ImageIcon
        if (column == imageColumnIndex && value instanceof ImageIcon) {
            ImageIcon originalIcon = (ImageIcon) value;
            // Resize the ImageIcon to a fixed size
            ImageIcon resizedIcon = resizeIcon(originalIcon, ICON_WIDTH, ICON_HEIGHT);

            setIcon(resizedIcon); // Set the resized ImageIcon in the cell
            setText(""); // No text needed when displaying image
            setHorizontalAlignment(CENTER); // Center-align the image
        } else {
            setIcon(null); // Clear icon if not an image column
            setText(value != null ? value.toString() : ""); // Display text normally
            setHorizontalAlignment(LEFT); // Left-align text
        }

        // Determine the background color based on selection and stock value
        if (isSelected) {
            c.setBackground(Color.YELLOW);
        } else {
            Object stockValue = table.getValueAt(row, stockColumnIndex);
            if (stockValue instanceof Number && ((Number) stockValue).intValue() < 5) {
                c.setBackground(Color.RED);
            } else {
                c.setBackground(table.getBackground());
            }
        }

        return c;
    }

    private ImageIcon resizeIcon(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image resizedImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImg);
    }
}
