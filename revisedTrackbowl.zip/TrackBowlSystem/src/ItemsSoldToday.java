
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import java.sql.PreparedStatement;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;
//import java.lang.String;
import java.sql.Statement;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.TimeZone;
import javax.swing.JFileChooser;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.ParseException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author User
 */
public final class ItemsSoldToday extends javax.swing.JFrame {

    private Connection con = null;
    private Statement st = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;

    private final DefaultTableModel model;
    private final TableRowSorter<DefaultTableModel> sorter;
    private static final String DbName = "trackbowl";
    private static final String DbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String DbUrl = "jdbc:mysql://localhost:3306/" + DbName;
    private static final String DbUsername = "root";
    private static final String DbPassword = "";
    private static final Logger LOGGER = Logger.getLogger(ItemsSoldToday.class.getName());

    static String accType;
    static String userLabel;
    //static int staffid = 012345;
    static double sales;
    static String date;
    static String staffid;

    public ItemsSoldToday(String userLabel, String staffid) {
        super(userLabel);
        this.staffid = staffid;
        initComponents();
        connectToDatabase();
        loadSoldItems();
        userShow.setText(userLabel);
        model = (DefaultTableModel) itemSoldTable.getModel();
        sorter = new TableRowSorter<>(model);
        itemSoldTable.setEnabled(true);
        calculatePrice();
        showCurrentDate();
        currentSales.setEditable(false);

    }

    private void connectToDatabase() {
        try {
            Class.forName(DbDriver);
            con = DriverManager.getConnection(DbUrl, DbUsername, DbPassword);
            st = con.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
            // Handle exceptions as needed
        }
    }

    private void loadSoldItems() {
        ResultSet rs = null;
        try {
            DefaultTableModel model = (DefaultTableModel) itemSoldTable.getModel();
            model.setRowCount(0);
            rs = st.executeQuery("SELECT * FROM itemsoldtable");
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("item_code"),
                    rs.getString("item_name"),
                    rs.getInt("quantity"),
                    rs.getDouble("total_price"),
                    rs.getString("Mode"),
                    rs.getString("staff_id"),
                    rs.getString("date sold")

                });
            }
        } catch (SQLException ex) {
            Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    void calculatePrice() {
        int sum = 0;
        String priceStr;
        double price;

        for (int i = 0; i < itemSoldTable.getRowCount(); i++) {
            priceStr = itemSoldTable.getValueAt(i, 3).toString();
            price = Double.parseDouble(priceStr);
            sum = (int) (sum + price);
        }

        currentSales.setText("₱" + sum);
        setTotalSales(sum);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        itemSoldTable = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        totalSalesByDate = new javax.swing.JButton();
        salesOnDate = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        currentSales = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        currentDateField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        userShow = new javax.swing.JLabel();
        refundButton = new javax.swing.JButton();
        exit = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        generatePdf = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Today's Sales");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        itemSoldTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Code", "Item Name", "Quantity", "Total Price (₱)", "Mode", "Staff ID", "Date Sold"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        itemSoldTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        itemSoldTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(itemSoldTable);
        if (itemSoldTable.getColumnModel().getColumnCount() > 0) {
            itemSoldTable.getColumnModel().getColumn(0).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(1).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(2).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(3).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(4).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(5).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(6).setResizable(false);
        }

        jPanel4.setBackground(new java.awt.Color(204, 0, 51));

        totalSalesByDate.setBackground(new java.awt.Color(255, 153, 51));
        totalSalesByDate.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        totalSalesByDate.setForeground(new java.awt.Color(255, 255, 255));
        totalSalesByDate.setText("View Sales by Date");
        totalSalesByDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalSalesByDateActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(255, 153, 51));
        jButton1.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Show All Sales");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(salesOnDate, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(totalSalesByDate)
                .addGap(26, 26, 26)
                .addComponent(jButton1)
                .addGap(19, 19, 19))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(totalSalesByDate)
                    .addComponent(salesOnDate, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 610, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 516, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 610, 550));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trackbowlPics/logo1 (1).png"))); // NOI18N
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        jLabel2.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jLabel2.setText("Sales History");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 140, -1));

        jPanel7.setBackground(new java.awt.Color(204, 0, 0));

        currentSales.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentSales, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentSales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, -1));

        jLabel5.setBackground(new java.awt.Color(204, 0, 0));
        jLabel5.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 0));
        jLabel5.setText("Current Sales Today:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 217, 150, -1));

        jPanel8.setBackground(new java.awt.Color(204, 0, 0));

        currentDateField.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentDateField, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentDateField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, -1, -1));

        jLabel6.setBackground(new java.awt.Color(204, 0, 0));
        jLabel6.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 0, 0));
        jLabel6.setText("Current Date:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 285, 150, -1));

        userShow.setFont(new java.awt.Font("Segoe UI Variable", 1, 12)); // NOI18N
        userShow.setForeground(new java.awt.Color(255, 255, 255));
        userShow.setText("jLabel1");
        jPanel2.add(userShow, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, 60, -1));

        refundButton.setBackground(new java.awt.Color(255, 153, 51));
        refundButton.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        refundButton.setForeground(new java.awt.Color(255, 255, 255));
        refundButton.setText("REFUND ITEM");
        refundButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refundButtonActionPerformed(evt);
            }
        });
        jPanel2.add(refundButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 150, -1));

        exit.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        exit.setForeground(new java.awt.Color(153, 0, 0));
        exit.setText("Back >>");
        exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitMouseClicked(evt);
            }
        });
        jPanel2.add(exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 520, -1, 16));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel4.setText("Refund an Item Sold Today");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 150, 20));

        generatePdf.setBackground(new java.awt.Color(204, 0, 0));
        generatePdf.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        generatePdf.setForeground(new java.awt.Color(255, 255, 255));
        generatePdf.setText("GENERATE PDF");
        generatePdf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generatePdfActionPerformed(evt);
            }
        });
        jPanel2.add(generatePdf, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, 150, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, 170, 550));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 814, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 567, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void refundButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refundButtonActionPerformed
        int selectedRow = itemSoldTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a transaction to refund", "No item selected", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String code = itemSoldTable.getValueAt(selectedRow, 0).toString();
        String name = itemSoldTable.getValueAt(selectedRow, 1).toString();
        int quantity = Integer.parseInt(itemSoldTable.getValueAt(selectedRow, 2).toString());
        String mode = itemSoldTable.getValueAt(selectedRow, 4).toString();
        String staff = itemSoldTable.getValueAt(selectedRow, 5).toString();
        Double totalPrice = Double.valueOf(itemSoldTable.getValueAt(selectedRow, 3).toString());
        String dateSoldString = itemSoldTable.getValueAt(selectedRow, 6).toString(); // Get the Date Sold as String

// Parse the Date Sold to a Date object
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dateSold;
        try {
            dateSold = dateFormat.parse(dateSoldString);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Error parsing date: " + e.getMessage(), "Date Parsing Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

// Get the current date
        Date currentDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            currentDate = sdf.parse(sdf.format(currentDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }

// Check if the Date Sold is before the start of the current day
        if (dateSold.before(currentDate)) {
            JOptionPane.showMessageDialog(null, "Refunds are not allowed for transactions made before today", "Refund Not Allowed", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with the refund?\n\nItem Name: " + name + "\nQuantity Sold: " + quantity + "\nTotal Price: ₱" + totalPrice, "Refund Confirmation", JOptionPane.YES_NO_OPTION);

        if (response == JOptionPane.YES_OPTION) {
            try {
                con.setAutoCommit(false); // Start transaction

                // Delete from itemsoldtable
                String sql = "DELETE FROM itemsoldtable WHERE item_code = ? AND quantity = ? AND Mode = ?";
                try (PreparedStatement pst = con.prepareStatement(sql)) {
                    pst.setString(1, code);
                    pst.setInt(2, quantity);
                    pst.setString(3, mode);
                    pst.executeUpdate();
                    System.out.println("Deleted from itemsoldtable");
                }

                // Remove row from JTable
                DefaultTableModel model = (DefaultTableModel) itemSoldTable.getModel();
                model.removeRow(selectedRow);

                // Update inventory_items
                String sql1 = "UPDATE inventory_items SET `Stocks Left` = `Stocks Left` + ? WHERE `id` = ?";
                try (PreparedStatement pst = con.prepareStatement(sql1)) {
                    pst.setInt(1, quantity);
                    pst.setString(2, code);
                    pst.executeUpdate();
                    System.out.println("Updated Inventory");
                }

                // Delete from all_items_sold
                AllItemsSold all = new AllItemsSold();
                all.refund(name, quantity, totalPrice, mode, staff, dateSoldString); // Pass the dateSoldString
                System.out.println("Deleted from all items sold");

                con.commit(); // Commit transaction
            } catch (SQLException ex) {
                try {
                    con.rollback(); // Rollback transaction in case of error
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                try {
                    con.setAutoCommit(true); // Restore default auto-commit behavior
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            calculatePrice();
        }


    }//GEN-LAST:event_refundButtonActionPerformed

    private void exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitMouseClicked
        // TODO add your handling code here:
        dispose();
        if (userShow.getText().equals("Staff")) {
            Display sales = new Display("Staff", "user", staffid);
            sales.show();
        } else if (userShow.getText().equals("Admin")) {
            Display sales = new Display("Admin", "user", "Admin");
            sales.show();
        }
    }//GEN-LAST:event_exitMouseClicked

    private void totalSalesByDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalSalesByDateActionPerformed
        // Get the selected date from the date picker
       // Get the selected date from the date picker
    
    Date selectedDate = salesOnDate.getDate();

    if (selectedDate == null) {
        JOptionPane.showMessageDialog(this, "Please select a date to view!", "Empty Date Field", JOptionPane.ERROR_MESSAGE);
        return; // Add this line to stop execution if no date is selected
    }

    showSalesByDate();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String formattedDate = sdf.format(selectedDate);

    double sum = 0.0;

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/trackbowl", "root", "")) {
        PreparedStatement pst = conn.prepareStatement("SELECT `total_price` FROM itemsoldtable WHERE `date sold` = ?");
        pst.setString(1, formattedDate);
        ResultSet rs = pst.executeQuery();

        if (!rs.isBeforeFirst()) { // Check if the ResultSet is empty
            JOptionPane.showMessageDialog(this, "There were no sales on " + formattedDate);
        } else {
            while (rs.next()) {
                String priceStr = rs.getString("total_price");
                sum += Double.parseDouble(priceStr);
            }
            String message = "Date: " + formattedDate + "\nTotal: PHP " + String.format("%.2f", sum);
            JOptionPane.showMessageDialog(this, message, "Show Total Sales", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }


    }//GEN-LAST:event_totalSalesByDateActionPerformed

    void showSalesByDate() {
        Date selectedDate = salesOnDate.getDate();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = sdf.format(selectedDate);

        DefaultTableModel model = (DefaultTableModel) itemSoldTable.getModel();
        model.setRowCount(0);

        double sum = 0.0;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/trackbowl", "root", "")) {
            PreparedStatement pst = conn.prepareStatement("SELECT * FROM itemsoldtable WHERE `date sold` = ?");
            pst.setString(1, formattedDate);
            ResultSet rs = pst.executeQuery();

            ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (rs.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    row[i - 1] = rs.getString(i);
                }
                model.addRow(row);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }
    private void generatePdfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generatePdfActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
    String path = "";
    JFileChooser choose = new JFileChooser();
    choose.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    int x = choose.showSaveDialog(this);

    if (x == JFileChooser.APPROVE_OPTION) {
        path = choose.getSelectedFile().getPath();
    } else {
        JOptionPane.showMessageDialog(this, "No directory selected!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    Document doc = new Document();

    try {
        PdfWriter.getInstance(doc, new FileOutputStream(path + "/Generated Reports.pdf"));
        doc.open();

        PdfPTable tbl = new PdfPTable(itemSoldTable.getColumnCount());

        // Add table headers
        for (int i = 0; i < itemSoldTable.getColumnCount(); i++) {
            tbl.addCell(itemSoldTable.getColumnName(i));
        }

        boolean hasData = false;
        double totalPrice = 0.0;
        
        // Add table data
        for (int i = 0; i < itemSoldTable.getRowCount(); i++) {
            for (int k = 0; k < itemSoldTable.getColumnCount(); k++) {
                tbl.addCell(itemSoldTable.getValueAt(i, k).toString());
            }
            totalPrice += Double.parseDouble(itemSoldTable.getValueAt(i, 3).toString());
            hasData = true;
        }

        if (hasData) {
            // Add total price row
            PdfPCell totalCell = new PdfPCell(new Paragraph("Total:"));
            totalCell.setColspan(itemSoldTable.getColumnCount() - 1);
            tbl.addCell(totalCell);
            tbl.addCell(String.valueOf(totalPrice));
            doc.add(tbl);
        } else {
            Paragraph par = new Paragraph("Nothing to Display");
            doc.add(par);
        }

        doc.close();
        
        JOptionPane.showMessageDialog(this, "Report Generated!");
    } catch (DocumentException | FileNotFoundException ex) {
        Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_generatePdfActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        salesOnDate.setDate(null);
        loadSoldItems();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * *
     */
    private void closeDatabaseConnection() {
        try {
            if (con != null) {
                con.close();

            }
        } catch (SQLException ex) {
            Logger.getLogger(ItemsSoldToday.class
                    .getName()).log(Level.SEVERE, null, ex);
            // Handle exceptions as needed
        }
    }

    public void showCurrentDate() {
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Manila"));

        // Get the current date and format it
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String currentDate = dateFormat.format(new Date());

        // Set the current date as the text of the JTextField
        currentDateField.setText(currentDate);
        currentDateField.setEditable(false);
        date = currentDate;

    }

    void setTotalSales(double sum) {
        sales = sum;
    }

    public double getSales() {
        return sales;
    }

    private void addToSales() {

        try {
            String sql = "INSERT INTO salestoday"
                    + "(`Date`,`Sales`)"
                    + "VALUES (?,?)";

            con = DriverManager.getConnection("jdbc:mysql://localhost/trackbowl", "root", "");
            pst = (PreparedStatement) con.prepareStatement(sql);
            pst.setString(1, currentDateField.getText());
            pst.setDouble(2, sales);
            pst.executeUpdate();

        } catch (HeadlessException | SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ItemsSoldToday.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ItemsSoldToday.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ItemsSoldToday.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ItemsSoldToday.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ItemsSoldToday(accType, staffid).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField currentDateField;
    private javax.swing.JTextField currentSales;
    private javax.swing.JLabel exit;
    private javax.swing.JButton generatePdf;
    private javax.swing.JTable itemSoldTable;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton refundButton;
    private com.toedter.calendar.JDateChooser salesOnDate;
    private javax.swing.JButton totalSalesByDate;
    private javax.swing.JLabel userShow;
    // End of variables declaration//GEN-END:variables
}
